﻿using System.Text.Json.Serialization;
using System.Text.Json;
using System.Text;
namespace JSONProcessing;


public class Hero
{
    private string _heroId;
    private string _heroName;
    private string _faction;
    private int _level;
    private string _castleLocation;
    private int _troops;
    private List<Unit> _units;
    
    [JsonConstructor]
    public Hero(string heroId, string heroName, string faction, int level, 
        string castleLocation, int troops, List<Unit> units)
    {
        _heroId = heroId;
        _heroName = heroName;
        _faction = faction;
        _level = level;
        _castleLocation = castleLocation;
        _troops = troops;
        _units = units;
        
        for (int i = 0; i < _units.Count; i++)
        {
            _units[i].HeroId = heroId;
            _units[i].IndAmongUnits = i;
            _units[i].LocationOrQuantityChanged += CountTroops;
        }
    }
    
    [JsonPropertyName("hero_id")]
    public string HeroId
    {
        get { return _heroId; }
        set { _heroId = value; Update(); }
    }
    [JsonPropertyName("hero_name")]
    public string HeroName
    {
        get { return _heroName; }
        set { _heroName = value; Update(); }
    }
    [JsonPropertyName("faction")]
    public string Faction
    {
        get { return _faction; }
        set { _faction = value; Update(); }
    }
    [JsonPropertyName("level")]
    public int Level
    {
        get { return _level; }
        set { _level = value; Update(); }
    }
    [JsonPropertyName("castle_location")]
    public string CastleLocation
    {
        get { return _castleLocation; }
        set { _castleLocation = value; Update(); CountTroops(); }
    }
    [JsonPropertyName("troops")]
    public int Troops
    {
        get { return _troops; }
        set { _troops = value; Update(); }
    }
    [JsonPropertyName("units")]
    public List<Unit> Units
    {
        get { return _units; }
        set { _units = value; Update(); CountTroops(); }
    }
    
    public void CountTroops()
    {
        _troops = 0;
        foreach (Unit unit in _units)
        {
            if (unit.CurrentLocation == _castleLocation)
                _troops += unit.Quantity;
        }
    }
    
    public string ToJson()
    {
        return JsonSerializer.Serialize(this, new JsonSerializerOptions(){WriteIndented = true});
    }

    public event EventHandler<UpdateEventArgs> Updated;

    protected virtual void Update()
    {
        Updated?.Invoke(this, new UpdateEventArgs());
    }
    
    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Hero Name:", HeroName));
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Faction:", Faction));
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Level:", Level));
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Castle Location:", CastleLocation));
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Troops:", Troops));

        return sb.ToString();
    }
}