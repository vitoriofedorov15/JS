namespace JSONProcessing;
using System.Text.Json;

public static class JsonChecking
{
    public static bool AllFields(string jsonString)
    {
        var requiredFields = new List<string> { "hero_id", "hero_name", "faction", "level", "castle_location", "troops", "units" };

        using (JsonDocument doc = JsonDocument.Parse(jsonString))
        {
            foreach (JsonElement hero in doc.RootElement.EnumerateArray())
            {
                foreach (string field in requiredFields)
                {
                    if (!hero.TryGetProperty(field, out _))
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
}

public static class CreateJson
{
    public static string MakeJson(List<Hero> heroes)
    {
        string jsonString = "[\n";
        foreach (var hero in heroes)
        {
            jsonString += hero.ToJson() + ",\n";
        }
        jsonString = jsonString.Remove(jsonString.Length - 2, 1);
        jsonString += "\n]";
        return jsonString;
    }
}

public class UpdateEventArgs : EventArgs
{
    private DateTime _updateTime;
    
}

public delegate void ChangeHappened();


public static class SaveJson
{
    private static DateTime _lastUpdate;
    private static List<Hero> _heroes;
    
    public static void SubscribeToChanges(List<Hero> heroes)
    {
        foreach (var hero in heroes)
        {
            _heroes = heroes;
            hero.Updated += Update;
            foreach (var unit in hero.Units)
            {
                unit.Updated += Update;
            }
        }
    }

    private static void Update(object sender, UpdateEventArgs e)
    {
        if (sender.GetType() == typeof(Hero))
        {
            for (int i = 0; i < _heroes.Count; i++)
            {
                if (_heroes[i].HeroId == ((Hero)sender).HeroId)
                {
                    _heroes[i] = (Hero)sender;
                }
            }
        }
        else
        {
            for (int i = 0; i < _heroes.Count; i++)
            {
                if (((Unit)sender).IndAmongUnits < _heroes[i].Units.Count)
                {
                    if (_heroes[i].HeroId == ((Unit)sender).HeroId)
                    {
                        _heroes[i].Units[((Unit)sender).IndAmongUnits] = (Unit)sender;
                    }
                }
            }
        }
        
    }
}

