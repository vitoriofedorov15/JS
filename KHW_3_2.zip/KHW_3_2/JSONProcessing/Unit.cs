using System.Text.Json.Serialization;
using System.Text.Json;
using System.Text;
namespace JSONProcessing;

public class Unit
{
    public event ChangeHappened LocationOrQuantityChanged;

    private string _unitName;
    private int _quantity;
    private int _experience;
    private string _currentLocation;
    
    [JsonConstructor]
    public Unit(string unitName, int quantity, int experience, string currentLocation)
    {
        _unitName = unitName;
        _quantity = quantity;
        _experience = experience;
        _currentLocation = currentLocation;
    }

    [JsonPropertyName("unit_name")]
    public string UnitName
    {
        get { return _unitName; }
        set
        {
            _unitName = value;
            OnUpdated();
        }
    }

    [JsonPropertyName("quantity")]
    public int Quantity
    {
        get { return _quantity; }
        set
        {
            _quantity = value;
            OnUpdated();
            LocationOrQuantityChanged?.Invoke();
        }
    }

    [JsonPropertyName("experience")]
    public int Experience
    {
        get { return _experience; }
        set
        {
            _experience = value;
            OnUpdated();
        }
    }

    [JsonPropertyName("current_location")]
    public string CurrentLocation
    {
        get { return _currentLocation; }
        set
        {
            _currentLocation = value;
            OnUpdated();
            LocationOrQuantityChanged?.Invoke();
        }
    }

    public string HeroId { get; set; }

    public int IndAmongUnits { get; set; }
    
    public string ToJson()
    {
        return JsonSerializer.Serialize(this, new JsonSerializerOptions() { WriteIndented = true });
    }
    
    public event EventHandler<UpdateEventArgs> Updated;
    
    protected virtual void OnUpdated()
    {
        Updated?.Invoke(this, new UpdateEventArgs());
    }
    
    public override string ToString()
    {
        StringBuilder sb = new StringBuilder();

        sb.AppendLine(String.Format("{0,-20} {1,36}", "Unit Name:", UnitName));
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Quantity:", Quantity));
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Experience:", Experience));
        sb.AppendLine(String.Format("{0,-20} {1,36}", "Current Location:", CurrentLocation));

        return sb.ToString();
    }
}