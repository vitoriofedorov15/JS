namespace JSONProcessing;
using System.Text.Json;

public class Methods
{
    public static class Menu
    {
        public static int ChooseAction()
        {
            Console.WriteLine();
            Console.WriteLine("Выберите пункт меню:");
            Console.WriteLine();
            Console.WriteLine("1. Показать всех героев");
            Console.WriteLine("2. Отсортировать героев");
            Console.WriteLine("3. Изменить героя");
            Console.WriteLine("4. Сохранить данные в файл");
            Console.WriteLine("5. Выбрать новый файл");
            Console.WriteLine("6. Завершить работу");
            Console.WriteLine();
            Console.Write("Ваш выбор: ");
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 6)
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                Console.Write("Ваш выбор: ");
            }
            return choice;
        }
    }
    
    public static class FileExtracting
    {
        public static string GetFileLines(string path)
        {
            string[] fileLines;
            string fileText;
            try
            {
                fileLines = File.ReadAllLines(path);
                fileText = string.Join("\n", fileLines);
            }
            catch
            {
                throw new ArgumentNullException();
            }

            return fileText;
        }
        
        public static void OpenFile(string path)
        {
            if (!File.Exists(path))
            {
                throw new FileNotFoundException();
            }

            if (!path.EndsWith(".json"))
            {
                throw new ArgumentException();
            }

            try
            {
                GetFileLines(path);
            }
            catch
            {
                throw new FormatException();
            }
        }
        
    }
    
    public static class WorkWithJson
    {
        public static (string, List<Hero>) GetFilePathAndHeroes()
        {
            bool goodPath = false;
            string path;
            List<Hero> heroes = new List<Hero>();
            do
            {
                Console.Write("Введите путь к файлу JSON: ");
                path = Console.ReadLine();
                try
                {
                    FileExtracting.OpenFile(path);
                    string jsonString = FileExtracting.GetFileLines(path);
                    try
                    {
                        if (JsonChecking.AllFields(jsonString))
                        {
                            heroes = JsonSerializer.Deserialize<List<Hero>>(jsonString);
                            goodPath = true;
                        }
                        else
                        {
                            Console.WriteLine("Неверный формат. Попробуйте снова.");
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Неверный формат. Попробуйте снова.");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Не удалось открыть файл. Попробуйте еще раз.");
                }
            } while (!goodPath);

            return (path, heroes);
        }
        
        
        public static (string, bool) SortAndOrder()
        {
            Console.WriteLine();
            Console.WriteLine("Выберите поле для сортировки:");
            Console.WriteLine();
            Console.WriteLine("1. Имя");
            Console.WriteLine("2. Фракция");
            Console.WriteLine("3. Уровень");
            Console.WriteLine("4. Местоположение замка");
            Console.WriteLine("5. Численность войска");
            Console.WriteLine();
            Console.Write("Ваш выбор: ");
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 5)
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                Console.WriteLine();
                Console.Write("Ваш выбор: ");
            }
            
            Console.Write("Отсортировать по возрастанию или убыванию? ");
            Console.Write("(1/2)");
            Console.Write(": ");
            string order = Console.ReadLine();
            while (order != "1" && order != "2")
            {
                Console.Write("Выберите между 1/2: ");
                order = Console.ReadLine();
            }
            string field = choice switch
            {
                1 => "hero_name",
                2 => "faction",
                3 => "level",
                4 => "castle_location",
                5 => "troops",
            };
            Console.WriteLine();
            return (field, order == "1");
        }
        
        public static (string, string) HeroAndField(List<Hero> heroes)
        {
            Console.Write("Введите ID героя: ");
            string heroId = Console.ReadLine();
            bool heroFound = false;
            foreach (var hero in heroes)
            {
                if (hero.HeroId == heroId)
                {
                    heroFound = true;
                    break;
                }
            }

            while (!heroFound)
            {
                Console.WriteLine("Герой с таким ID не найден. Попробуйте снова.");
                heroId = Console.ReadLine();
                if (heroId == "")
                {
                    return (null, null);
                }
                
                foreach (var hero in heroes)
                {
                    if (hero.HeroId == heroId)
                    {
                        heroFound = true;
                        break;
                    }
                }
            }
            
            Console.WriteLine();
            Console.WriteLine("Выберите поле для изменения:");
            Console.WriteLine();
            Console.WriteLine("1. Имя");
            Console.WriteLine("2. Фракция");
            Console.WriteLine("3. Уровень");
            Console.WriteLine("4. Местоположение замка");
            Console.WriteLine("5. Юниты");
            Console.WriteLine();
            Console.Write("Ваш выбор: ");
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 5)
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                Console.Write("Ваш выбор: ");
            }

            string field = choice switch
            {
                1 => "hero_name",
                2 => "faction",
                3 => "level",
                4 => "castle_location",
                5 => "units",
            };
            return (heroId, field);
        }
        public static string GetStringValue(string field)
        {
            Console.Write($"Введите новое значение поля {field}: ");
            string newValue = Console.ReadLine();
            return newValue;
        }
        
        public static int GetIntValue()
        {
            Console.Write($"Введите новое значение поля level: ");
            int newValue;
            while (!int.TryParse(Console.ReadLine(), out newValue))
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                Console.Write($"Введите новое значение поля level: ");
            }
            
            return newValue;
        }
        
        public static void GetUnitsValue(ref Hero hero)
        {
            Console.WriteLine("Список всех юнитов героя: ");
            Console.WriteLine();
            foreach (var unit in hero.Units)
            {
                Console.WriteLine(unit.ToString());
            }

            Console.WriteLine();
            Console.Write("Введите название юнита, который вы хотите изменить: ");
            string originalUnitName = Console.ReadLine();
            Unit unitToChange = hero.Units.Find(unit => unit.UnitName == originalUnitName);
            while (unitToChange == null)
            {
                Console.WriteLine("Юнит с таким названием не найден. Попробуйте снова.");
                Console.WriteLine();
                Console.Write("Введите название юнита, который вы хотите изменить: ");
                originalUnitName = Console.ReadLine();
                unitToChange = hero.Units.Find(unit => unit.UnitName == originalUnitName);
            }

            Console.WriteLine();
            Console.Write("Введите новое название юнита: ");
            string unitName = Console.ReadLine();
            unitToChange.UnitName = unitName;
            Console.Write("Введите новую численность: ");
            int unitQuantity;
            while (!int.TryParse(Console.ReadLine(), out unitQuantity))
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                Console.WriteLine();
                Console.Write("Введите новую численность: ");
            }
            unitToChange.Quantity = unitQuantity;

            Console.Write("Введите новый опыт юнита: ");
            int unitExperience;
            while (!int.TryParse(Console.ReadLine(), out unitExperience))
            {
                Console.WriteLine("Некорректный ввод! Попробуйте снова.");
                Console.WriteLine();
                Console.Write("Введите новый опыт юнита: ");
            }
            unitToChange.Experience = unitExperience;

            Console.Write("Введите новую локацию юнита: ");
            string unitLocation = Console.ReadLine();
            unitToChange.CurrentLocation = unitLocation;
        }
        
        public static void SaveHero(List<Hero> heroes)
        {
            string path;
            do
            {
                Console.Write("Введите путь к файлу JSON для сохранения данных: ");
                path = Console.ReadLine();

                if (!path.EndsWith(".json"))
                {
                    Console.WriteLine("Путь должен указывать на файл формата .json. Попробуйте снова.");
                    continue;
                }

                try
                {
                    string jsonString = CreateJson.MakeJson(heroes);
                    File.WriteAllText(path, jsonString);
                }
                catch
                {
                    Console.WriteLine("Не удалось открыть файл для записи. Попробуйте снова.");
                    continue;
                }

                break;
            } while (true);

            Console.WriteLine("Файл сохранен.");
        }
    }
    public static class PrintJson
    {
        public static void ShowAllHeroes(List<Hero> heroes)
        {
            Console.Write("\u001b[2J\u001b[3J");
            Console.Clear();
            Console.WriteLine("Список героев:");
            Console.WriteLine();
            
            Console.WriteLine("{0,-36} {1,20}",
                "Hero ID", "Hero Name");

            foreach (var hero in heroes)
            {
                Console.WriteLine("{0,-36} {1,20}",
                    hero.HeroId, hero.HeroName);
            }
        }
    }
    
    public static class HeroProcessing
    {
        public static void SortByField(ref List<Hero> heroes, string field, bool order)
        {
            heroes.Sort((hero1, hero2) =>
            {
                int result;
                switch (field)
                {
                    case "hero_name":
                        result = hero1.HeroName.CompareTo(hero2.HeroName);
                        break;
                    case "faction":
                        result = hero1.Faction.CompareTo(hero2.Faction);
                        break;
                    case "level":
                        result = hero1.Level.CompareTo(hero2.Level);
                        break;
                    case "castle_location":
                        result = hero1.CastleLocation.CompareTo(hero2.CastleLocation);
                        break;
                    default:
                        result = hero1.Troops.CompareTo(hero2.Troops);
                        break;
                }
                return order ? result : -result;
            });
        }
        
        public static void ChangeField(ref List<Hero> heroes, string heroId, string field)
        {
            for (int i = 0; i < heroes.Count; i++)
            {
                var hero = heroes[i];
                if (hero.HeroId == heroId)
                {
                    switch (field)
                    {
                        case "hero_name":
                            hero.HeroName = WorkWithJson.GetStringValue(field);
                            break;
                        case "faction":
                            hero.Faction = WorkWithJson.GetStringValue(field);
                            break;
                        case "level":
                            hero.Level = WorkWithJson.GetIntValue();
                            break;
                        case "castle_location":
                            hero.CastleLocation = WorkWithJson.GetStringValue(field);
                            break;
                        case "units":
                            WorkWithJson.GetUnitsValue(ref hero);
                            break;
                    }
                }
            }
        }
    }
}