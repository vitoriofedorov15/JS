﻿using JSONProcessing;

internal static class Program
{
    public static void Main()
    {
        bool repeat = true;
        try
        {
            do
            {
                List<Hero> heroes;
                string path;
                (path, heroes) = Methods.WorkWithJson.GetFilePathAndHeroes();
                SaveJson.SubscribeToChanges(heroes);
                int choice = 0;
                while (choice < 5)
                {
                    choice = Methods.Menu.ChooseAction();
                    switch (choice)
                    {
                        case 1:
                            Methods.PrintJson.ShowAllHeroes(heroes);
                            break;
                        case 2:
                            var (sortingField, order) = Methods.WorkWithJson.SortAndOrder();
                            Methods.HeroProcessing.SortByField(ref heroes, sortingField, order);
                            break;
                        case 3:
                            var (heroId, changingField) =
                                Methods.WorkWithJson.HeroAndField(heroes);
                            if ((heroId != null) && (changingField != null))
                            {
                                Methods.HeroProcessing.ChangeField(ref heroes, heroId, changingField);
                            }
                            break;
                        case 4:
                            Methods.WorkWithJson.SaveHero(heroes);
                            break;
                        case 5:
                            break;
                        case 6:
                            return;
                    }
                }
            } while (repeat);
        }
        catch (Exception)
        {
            Console.WriteLine("Произошла непредвиденная ошибка. Программа будет завершена.");
        }
    }
}